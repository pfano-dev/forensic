export default [
  {
    title: 'How to become a forensic technician in South Africa …',
    image: 'https://lirp.cdn-website.com/5e843f35/dms3rep/multi/opt/IMG_4921-960w.jpg',
    cta: 'View article', 
    horizontal: true
  },
  {
    title: 'The VBS Scandal …',
    image: 'https://lirp.cdn-website.com/5e843f35/dms3rep/multi/opt/Post+3-960w.png',
    cta: 'View article'
  },
  {
    title: 'Understanding Fields of Forensic Science in South Africa …',
    image: 'https://lirp.cdn-website.com/5e843f35/dms3rep/multi/opt/personal_development-1200x627-960w.jpg',
    cta: 'View article' 
  },
  {
    title: 'Understanding Forensic Careers Through Case Examples …',
    image: 'https://irp-cdn.multiscreensite.com/5e843f35/dms3rep/multi/Oscar.bmp',
    cta: 'View article' 
  },
  {
    title: 'SIM swop fraud rises by 104% …',
    image: 'https://lirp.cdn-website.com/md/unsplash/dms3rep/multi/opt/photo-1528715442870-4161e5d051ad-960w.jpg',
    cta: 'View article', 
    horizontal: true
  },
];