
import { ImageBackground, Image, StyleSheet, StatusBar, Dimensions, Platform, Linking } from 'react-native';
import { Block, Button, Text, theme } from 'galio-framework';


import React,{useState , useEffect} from 'react';
import { View,TouchableOpacity, KeyboardAvoidingView, 
         TextInput,TouchableWithoutFeedback,
         Keyboard, ScrollView  }
         from 'react-native';

export default class Pro extends React.Component {
  render() {
    const { navigation } = this.props;

    return (
      <KeyboardAvoidingView style={styles.container}>

      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
<ScrollView>
        <View style={styles.inner}>
 
        <Text style={{fontSize:20,color:'gray',marginBottom:10,fontWeight:'bold'}}>Add New Case</Text>
          <TextInput placeholder="Case Number" style={styles.textInput} 
          
          // value={formState.idNumber} onChangeText={text => setTask("idNumber",text)}

          />

          <TextInput placeholder="Case Name" style={styles.textInput} 
            // value={formState.vehicleType} onChangeText={text => setTask("vehicleType",text)}
          />

        
          <TextInput placeholder="Timestamp" style={styles.textInput}
            // value={formState.RegistrationNumber} onChangeText={text => setTask("RegistrationNumber",text)}
          />
          <Text style={{fontSize:20,color:'gray'}}>Description</Text>
          <TextInput placeholder="" style={[styles.textInput,{height:150}]} 
            
          />
        
         
          <TouchableOpacity style={styles.btnContainer}
          // onPress={}
          >
         <Text style={{color:'white', fontWeight:'bold',fontSize:30}}>submit</Text>
          </TouchableOpacity>



          
        </View>
        </ScrollView>

      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
    );
  }
}

 
const styles = StyleSheet.create({
  container: {
  height:'100%',
  width:'100%',
  backgroundColor:'white'
  },
  inner: {
    padding: 24,
    flex: 1,
    justifyContent: 'space-evenly',
    paddingVertical:100
  },

  textInput: {
    height: 60,
    backgroundColor:'#eee',
    fontSize:20,
    paddingLeft:20,
    marginBottom: 25,
    borderRadius:10,
    marginTop:10
  },
  btnContainer: {
    backgroundColor: "#90caf9",
    marginTop: 22,
    height:50,
    alignItems:'center'
    ,justifyContent:"center",
    borderRadius:10
  },

  innerView: {
    justifyContent:'space-between',
    flexDirection:'row'
  },
});

