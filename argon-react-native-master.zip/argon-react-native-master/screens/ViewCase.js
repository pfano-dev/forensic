//galio
import { Block, Text, theme } from "galio-framework";
import {
    ScrollView,
  StyleSheet,
} from "react-native";
import React from "react";


// Argon themed components
import { argonTheme, tabs, Images } from "../constants";
import { Button, Header, Icon, Input } from "../components";


class ViewCase extends React.Component {

  render() {
    const { navigation } = this.props;
    return (
    <ScrollView>
      <Block flex center>
            <Block row style={{ marginTop: theme.SIZES.BASE }}>
                <Button style={styles.card}>
                    <Text size={13}  style={{ padding:10,fontWeight:"bold"}}>
                        Case No: cas3652
                    </Text>
                    <Text size={13} >
                        Case Name: MiWay
                    </Text>

                    
                    <Text size={13} >
                        Timestamp: 10/9/2022 12:50:21 SAST 
                    </Text>
                        <Text size={13} color={argonTheme.COLORS.MUTED} style={{ padding:10}}>
                        Forensic science, also known as criminalistics,
                         is the application of science to criminal and civil laws,
                          mainly—on the criminal side—during criminal investigation,
                         as governed by the legal standards of admissible evidence and criminal procedure.

                         Forensic science, also known as criminalistics,
                         is the application of science to criminal and civil laws,
                          mainly—on the criminal side—during criminal investigation,
                         as governed by the legal standards of admissible evidence and criminal procedure.

                         Forensic science, also known as criminalistics,
                         is the application of science to criminal and civil laws,
                          mainly—on the criminal side—during criminal investigation,
                         as governed by the legal standards of admissible evidence and criminal procedure.
                        </Text>
                </Button>
            </Block>



            

        </Block>
        </ScrollView>
    );
  }
}


const styles = StyleSheet.create({
        passwordCheck: {
            paddingLeft: 15,
            paddingTop: 13,
            paddingBottom: 30
        },
        socialButtons: {
        width: 120,
        height: 40,
        backgroundColor: "#fff",
        shadowColor: argonTheme.COLORS.BLACK,
        shadowOffset: {
          width: 0,
          height: 4
        },
        shadowRadius: 8,
        shadowOpacity: 0.1,
        elevation: 1
      },
      card: {
        width: 320,
        height: '90%',
        margin: 10,
        padding:15,
        backgroundColor: "#fff",
        shadowColor: argonTheme.COLORS.BLACK,
        shadowOffset: {
          width: 0,
          height: 4
        },
        shadowRadius: 8,
        shadowOpacity: 0.1,
        elevation: 1
      },
      socialTextButtons: {
        color: argonTheme.COLORS.PRIMARY,
        fontWeight: "800",
        fontSize: 14
      },
    
})


export default ViewCase;
