import React from 'react';
import { StyleSheet, Dimensions, ScrollView, Text,View,TouchableOpacity } from 'react-native';
import { Block, theme } from 'galio-framework';

const { width } = Dimensions.get('screen');
// Argon themed components
import { argonTheme, tabs } from "../constants/";
import { Button, Header, Icon, Input } from "../components";

class Home extends React.Component {
  renderArticles = () => {
    const { navigation } = this.props;
   
    return (
      <Block
        >
          <Block style={{height:70 , alignItems: 'center',justifyContent: 'center',}}>
          <Text style={{margin:20,fontSize:20,fontWeight:'bold',color:'gray'}}>Matika Ndalama</Text>
          </Block>

          <TouchableOpacity
         onPress={()=>navigation.navigate("Case")}
        >
                <Block style={styles.cardL} >
                    <Text style={{margin:20,fontSize:20,fontWeight:'bold',color:'white'}}>Latest Case</Text>
                </Block>
                </TouchableOpacity>

                <TouchableOpacity
         onPress={()=>navigation.navigate("Case")}
        >
                <Block style={styles.card} >
                <Text style={{margin:20,fontSize:20,fontWeight:'bold',color:'white'}}>My Case</Text>
                </Block>
                </TouchableOpacity>
                <TouchableOpacity
         onPress={()=>navigation.navigate("ForensicNews")}
        >
                <Block style={styles.card} >
                <Text style={{margin:20,fontSize:20,fontWeight:'bold',color:'white'}}>News</Text>
                </Block>
                </TouchableOpacity>
                <TouchableOpacity
         onPress={()=>navigation.navigate("Elements")}
        >
                <Block style={styles.card} >
                <Text style={{margin:20,fontSize:20,fontWeight:'bold',color:'white'}}>Notes</Text>
                </Block>
                </TouchableOpacity>
               
            
      </Block>
    )
  }

  render() {
    return (
      <Block style ={{ alignItems: 'center',justifyContent: 'center',}}>
        {this.renderArticles()}
      </Block>
    );
  }
}

const styles = StyleSheet.create({

  card: {
    width: 380,
    height: 130,
    margin: 10,
    backgroundColor: "#9575cd",
    shadowColor: argonTheme.COLORS.BLACK,
    borderRadius:20,
    alignItems: 'center',
    justifyContent: 'center'
    
  },
  cardL: {
    width: 380,
    height: 230,
    margin: 10,
    backgroundColor: "#42a5f5",
    shadowColor: argonTheme.COLORS.BLACK,
    borderRadius:20,
    alignItems: 'center',
    justifyContent: 'center'
    
  }
});

export default Home;
