//galio
import { Block, Text, theme } from "galio-framework";
// import {
//     ScrollView,
//   StyleSheet,
// } from "react-native";
import { StyleSheet, Dimensions, ScrollView,View,TouchableOpacity } from 'react-native';
import React from "react";
import { Card } from 'galio-framework';


// Argon themed components
import { argonTheme, tabs } from "../constants/";
import { Button, Header, Input } from "../components";
import Icon from 'react-native-vector-icons/Ionicons';



class Case extends React.Component {



  render() {
    const { navigation } = this.props;
    

    return (
    <ScrollView>
      <Block flex center>

      <TouchableOpacity
        onPress={()=>navigation.navigate("Pro")}
        style={{justifyContent:"center",alignItems:'center',flexDirection: 'row'}}
        >
          <Icon name="add-circle-outline" size={25} color="#42a5f5"  style={{justifyContent:"center",alignItems:'center',marginTop:15}} />
           
         <Text style={{ fontSize:20,fontWeight:'bold',marginTop:10,color:'#42a5f5',marginLeft:5 }}>create Case</Text>

        </TouchableOpacity>

    

            <Block row style={{ marginTop: theme.SIZES.BASE }}>
             
                <Button style={styles.card} onPress={() => navigation.navigate("ViewCase")}>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case No: cas3652
                    </Text>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case Name: MiWay
                    </Text>
                 
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Timestamp: 10/9/2022 12:50:21 SAST 
                    </Text>
                      
                </Button>
            </Block>

            <Block row style={{ marginTop: theme.SIZES.BASE }}>
            <Button style={styles.card} onPress={() => navigation.navigate("ViewCase")}>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case No: cas3652
                    </Text>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case Name: MiWay
                    </Text>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Timestamp: 10/9/2022 12:50:21 SAST 
                    </Text>
                </Button>
            </Block>

            <Block row style={{ marginTop: theme.SIZES.BASE }}>
                <Button style={styles.card} onPress={() => navigation.navigate("ViewCase")}>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case No: cas3652
                    </Text>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case Name: MiWay
                    </Text>
                   
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Timestamp: 10/9/2022 12:50:21 SAST 
                    </Text>
                        
                </Button>
            </Block>

            <Block row style={{ marginTop: theme.SIZES.BASE }}>
                <Button style={styles.card} onPress={() => navigation.navigate("ViewCase")}>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case No: cas3652
                    </Text>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case Name: MiWay
                    </Text>
                  
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Timestamp: 10/9/2022 12:50:21 SAST 
                    </Text>
                      
                </Button>
            </Block>

          
            <Block row style={{ marginTop: theme.SIZES.BASE }}>
                <Button style={styles.card} onPress={() => navigation.navigate("ViewCase")}>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case No: cas3652
                    </Text>
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Case Name: MiWay
                    </Text>
                    
                    <Text size={13} color={argonTheme.COLORS.MUTED}>
                        Timestamp: 10/9/2022 12:50:21 SAST 
                    </Text>
                       
                </Button>
            </Block>

        </Block>
        </ScrollView>
    );
  }
}


const styles = StyleSheet.create({
        passwordCheck: {
            paddingLeft: 15,
            paddingTop: 13,
            paddingBottom: 30
        },
        socialButtons: {
        width: 120,
        height: 40,
        backgroundColor: "#fff",
        shadowColor: argonTheme.COLORS.BLACK,
        shadowOffset: {
          width: 0,
          height: 4
        },
        shadowRadius: 8,
        shadowOpacity: 0.1,
        elevation: 1
      },
      card: {
        width: 320,
        height: 100,
        margin: 10,
        backgroundColor: "#fff",
        shadowColor: argonTheme.COLORS.BLACK,
        shadowOffset: {
          width: 0,
          height: 4
        },
        shadowRadius: 8,
        shadowOpacity: 0.1,
        elevation: 1
      },
      socialTextButtons: {
        color: argonTheme.COLORS.PRIMARY,
        fontWeight: "800",
        fontSize: 14
      },
    
})


export default Case;
